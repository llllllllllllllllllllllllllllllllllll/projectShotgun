package xuhao.projectshotgun;

/**
 * Created by Rick on 2016/4/15.
 */


import android.util.Log;

import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfDouble;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

import java.util.ArrayDeque;

public class TimmAlgorithm {


    // Size constants
    int kEyePercentTop = 35;
    int kEyePercentSide = 20;
    int kEyePercentHeight = 15;
    int kEyePercentWidth = 20;

    // Preprocessing
    boolean kSmoothFaceImage = false;
    double kSmoothFaceFactor = 0.005;

    // Algorithm Parameters
    int kFastEyeWidth = 50;
    int kWeightBlurSize = 5;
    boolean kEnableWeight = true;
    double kWeightDivisor = 1;
    double kGradientThreshold = 50;

    // Postprocessing
    boolean kEnablePostProcess = false;
    double kPostProcessThreshold = 0.97;





    //   Mat floodKillEdges(Mat mat);


    double[][] matToArray(Mat fv) {

        int w = (int) fv.size().width;
        int h = (int) fv.size().height;
        double[][] buff = new double[h][w];

        //Log.d("mattoarraywh",String.valueOf(w)+"w***"+String.valueOf(h)+"***h");
        for (int i = 0; i < h; i++) {
            for (int j = 0; j < w; j++) {
                buff[i][j] = fv.get(i, j)[0];
                //    Log.d("mattoarrayfor",String.valueOf(i)+"i***"+String.valueOf(j)+"***j");
            }

        }
        return buff;

    }

    //TODO
    Point unscalePoint(Point p, Rect origSize) {
        float ratio = (((float) kFastEyeWidth) / origSize.width);
        int x = (int) Math.round(p.x / ratio);
        int y = (int) Math.round(p.y / ratio);
        return new Point(x, y);
    }


    double[][] computeMatXGradient(double[][] mat, int w, int h) {
        double[][] out = new double[h][w];

        for (int y = 0; y < h; ++y) {

            // out.put(y,0, (mat.get(y,1)[0]-mat.get(y,0)[0]));

            out[y][0] = mat[y][1] - mat[y][0];

            for (int x = 1; x < w - 1; ++x) {

                //   out.put(y,x,mat.get(y,x+1)[0]-(mat.get(y,x-1)[0]/2));

                out[y][x] = (mat[y][x + 1] - mat[y][x - 1]) / 2.0;


            }


            //  out.put(y,(int)mat.size().width-1,mat.get(y,(int)mat.size().width-1)[0]-mat.get(y,(int)mat.size().width-2)[0]);
            out[y][w - 1] = mat[y][w - 1] - mat[y][w - 2];
        }

        return out;
    }

    //  Main Algorithm

    void testPossibleCentersFormula(int x, int y, double[][] weight, double gx, double gy, double[][] out, int w, int h) {
        // for all possible centers

        for (int cy = 0; cy < h; ++cy) {


            for (int cx = 0; cx < w; ++cx) {
                if (x == cx && y == cy) {
                    continue;
                }
                // create a vector from the possible center to the gradient origin
                double dx = x - cx;
                double dy = y - cy;
                // normalize d
                double magnitude = Math.sqrt((dx * dx) + (dy * dy));
                dx = dx / magnitude;
                dy = dy / magnitude;

                double dotProduct = dx * gx + dy * gy;

                dotProduct = Math.max(0.0, dotProduct);
                // square and multiply by the weight
                if (kEnableWeight) {


                    //  out.put(cy,cx,out.get(cy,cx)[0] +  dotProduct * dotProduct * (weight[cy][cx]/kWeightDivisor));
                    out[cy][cx] = out[cy][cx] + dotProduct * dotProduct * (weight[cy][cx] / kWeightDivisor);
                } else {


                    //  out.put(cy,cx,out.get(cy,cx)[0]+dotProduct * dotProduct);
                    out[cy][cx] = out[cy][cx] + dotProduct * dotProduct;
                }

            }
        }

    }

    Core.MinMaxLocResult findEyeCenter(double[][] eyeROI, int eyeHeight, Mat eyemat) {


        //eyeROI = scaleToFastSize(eyeROI, eyeROI);
        //      Log.d("time","scaleToFastSize  complete");

        int w = 50;



        double[][] gradientX = computeMatXGradient(eyeROI, w, eyeHeight);

        /*
        Mat gradientXmat = new Mat();
        Imgproc.Scharr(eyemat, gradientXmat, CvType.CV_32F, 1, 0);
        Mat gradientYmat = new Mat();
        Imgproc.Scharr(eyemat.t(), gradientYmat, CvType.CV_32F, 0, 1);
        gradientYmat = gradientYmat.t();
        */

        //     Log.d("time","computeMatXGradient  complete");

        //transpose
        double[][] eyeROIT = new double[w][eyeHeight];
        for (int i = 0; i < eyeHeight; i++) {
            for (int j = 0; j < w; j++) {
                eyeROIT[j][i] = eyeROI[i][j];
            }
        }
        double[][] gradientYt = computeMatXGradient(eyeROIT, eyeHeight, w);
        double[][] gradientY = new double[eyeHeight][w];
        for (int i = 0; i < eyeHeight; i++) {
            for (int j = 0; j < w; j++) {
                gradientY[i][j] = gradientYt[j][i];
            }
        }
        //    Log.d("time"," computeMatYGradient complete");


        //-- Normalize and threshold the gradient
        // compute all the magnitudes
        double[][] mags = matrixMagnitude(gradientX, gradientY, w, eyeHeight);
       // Mat magsMat = new Mat();

       // Core.magnitude(gradientXmat, gradientYmat, magsMat);
        //     Log.d("time"," matrixMagnitude complete");


        //compute the threshold
        Mat magsm = new Mat(eyeHeight, w, CvType.CV_8U);

        double[] t1 = new double[1];
        //TODO
        for (int i = 0; i < eyeHeight; ++i) {
            for (int j = 0; j < w; ++j) {
                t1[0] = mags[i][j];
                magsm.put(i, j, t1);
            }
        }

        double gradientThresh = computeDynamicThreshold(magsm, kGradientThreshold);

     //   Log.d("thresh", String.valueOf(gradientThresh));


        //normalize

        for (int y = 0; y < eyeHeight; ++y) {

            for (int x = 0; x < w; ++x) {


                // double gX = gradientX.get(y,x)[0];
                double gX = gradientX[y][x];
                // double gY = gradientY.get(y,x)[0];
                double gY = gradientY[y][x];

                double magnitude = mags[y][x];

                if (magnitude > gradientThresh) {

                    //  gradientX.put(y,x,gX/magnitude);
                    gradientX[y][x] = gX / magnitude;
                    //  gradientY.put(y,x,gY/magnitude);
                    gradientY[y][x] = gY / magnitude;
                } else {

                    //  gradientX.put(y,x,0.0);
                    //  gradientY.put(y,x,0.0);
                    gradientX[y][x] = 0.0;
                    gradientY[y][x] = 0.0;

                }
            }
        }

        //     Log.d("time","normalize  complete");


        //-- Create a weighting image
        Mat weight = new Mat();
        Imgproc.GaussianBlur(eyemat, weight, new Size(kWeightBlurSize, kWeightBlurSize), 0, 0);

        double[][] weightArray = matToArray(weight);
        for (int y = 0; y < eyeHeight; ++y) {

            for (int x = 0; x < w; ++x) {

                //  weight.put(y,x,255 - weight.get(y,x)[0]);
                weightArray[y][x] = 255.0 - weightArray[y][x];
            }
        }

        //    Log.d("time","blur  complete");


        //-- Run the algorithm for each possible gradient location


        // evaluates every possible center for each gradient location instead of
        // every possible gradient location for every center.

        double[][] outSum = new double[eyeHeight][w];
        for (int i = 0; i < eyeHeight; i++) {
            for (int j = 0; j < w; j++) {
                outSum[i][j] = 0.0;
            }
        }
        for (int y = 0; y < eyeHeight; ++y) {

            for (int x = 0; x < w; ++x) {


                double gX = gradientX[y][x];

                double gY = gradientY[y][x];
                if (gX == 0.0 && gY == 0.0) {
                    continue;
                }
                testPossibleCentersFormula(x, y, weightArray, gX, gY, outSum, w, eyeHeight);
            }
        }


        Mat outsum = new Mat(eyeHeight, w, CvType.CV_32F);
        double[] t = new double[1];
        for (int i = 0; i < eyeHeight; ++i) {
            for (int j = 0; j < w; ++j) {
                t[0] = outSum[i][j];
                outsum.put(i, j, t);

            }

        }

        //    Log.d("time"," evaluate dotproduct complete");


        // scale all the values down, basically averaging them
        double numGradients = (w * eyeHeight);
        Mat out = new Mat();
        outsum.convertTo(out, CvType.CV_32F, 1.0 / numGradients);


        //-- Find the maximum point

        Core.MinMaxLocResult minmaxResult = Core.minMaxLoc(outsum);

        double maxVal = minmaxResult.maxVal;
        //Log.d("maxVal",String.valueOf(maxVal));


        //-- Flood fill the edges
        if (kEnablePostProcess) {
            Mat floodClone = new Mat();
            // double floodThresh = computeDynamicThreshold(out, 1.5);
            double floodThresh = maxVal * kPostProcessThreshold;
            Imgproc.threshold(outsum, floodClone, floodThresh, 0.0f, Imgproc.THRESH_TOZERO);

            Mat mask = floodKillEdges(floodClone);

            // Imgproc.resize(debugwindow,debugwindow,debugwindow.size());


            minmaxResult = Core.minMaxLoc(outsum, mask);

            maxVal = minmaxResult.maxVal;
         //   Log.d("maxVal", String.valueOf(maxVal));

        }
        return minmaxResult;


    }

    //  Postprocessing

    boolean floodShouldPushPoint(Point np, Mat mat) {
        return inMat(np, (int) mat.size().height, (int) mat.size().width);
    }

    // returns a mask
    Mat floodKillEdges(Mat mat) {
        Imgproc.rectangle(mat, new Point(0, 0), new Point(mat.size().width, mat.size().height), new Scalar(255));

        Mat mask = new Mat(mat.size(), CvType.CV_8U, new Scalar(255));
        ArrayDeque<Point> toDo = new ArrayDeque<>();
        toDo.add(new Point(0, 0));
        while (!toDo.isEmpty()) {
            Point p = toDo.poll();

            if (mat.get((int) p.x, (int) p.y)[0] == 0.0f) {
                continue;
            }
            // add in every direction
            Point np = new Point(p.x + 1, p.y); // right
            if (floodShouldPushPoint(np, mat)) toDo.add(np);
            np.x = p.x - 1;
            np.y = p.y; // left
            if (floodShouldPushPoint(np, mat)) toDo.add(np);
            np.x = p.x;
            np.y = p.y + 1; // down
            if (floodShouldPushPoint(np, mat)) toDo.add(np);
            np.x = p.x;
            np.y = p.y - 1; // up
            if (floodShouldPushPoint(np, mat)) toDo.add(np);
            // kill it

            mat.put((int) p.x, (int) p.y, 0.0f);

            mask.put((int) p.x, (int) p.y, 0);
        }
        return mask;
    }


    boolean inMat(Point p, int rows, int cols) {
        return ((p.x >= 0) && (p.x < cols) && (p.y >= 0) && (p.y < rows));
    }

    double[][] matrixMagnitude(double[][] matX, double[][] matY, int w, int h) {
        double[][] mags = new double[h][w];
        for (int y = 0; y < h; ++y) {

            for (int x = 0; x < w; ++x) {

                //double gX = matX.get(y,x)[0];
                double gX = matX[y][x];

                //double gY = matY.get(y,x)[0];
                double gY = matY[y][x];


                //  mags.put(y,x,magnitude);
                mags[y][x] = Math.sqrt((gX * gX) + (gY * gY));
            }

        }
        return mags;
    }

    double computeDynamicThreshold(Mat mat, double stdDevFactor) {
        MatOfDouble stdMagnGrad = new MatOfDouble();
        MatOfDouble meanMagnGrad = new MatOfDouble();
        Core.meanStdDev(mat, meanMagnGrad, stdMagnGrad);

        double stdDev = stdMagnGrad.get(0, 0)[0] / Math.sqrt(mat.size().height * mat.size().width);
        return (stdDevFactor * stdDev + meanMagnGrad.get(0, 0)[0]);
    }
}
