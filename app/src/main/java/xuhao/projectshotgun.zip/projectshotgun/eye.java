package xuhao.projectshotgun;

import cn.bmob.v3.BmobObject;
import cn.bmob.v3.datatype.BmobFile;

/**
 * Created by Rick on 2016/5/16.
 */
 public class eye extends BmobObject {
    private String perclos;
    private String time;
    private String UUID;
    public eye(){

    }

    public eye(String perclos,String time,String uuid){
        this.perclos =perclos;
        this.time = time;
        this.UUID=uuid;
    }

    public void setPerclos(String perclos) {
        this.perclos = perclos;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public void setUUID(String uuid){this.UUID=uuid;}

}

