package xuhao.projectshotgun;

/**
 * Created by Rick on 2016/4/28.
 */

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

public class SimpleDrawingView extends View {
    // setup initial color
    private final int paintColor = Color.BLACK;
    // defines paint and canvas
    Paint drawPaint = new Paint();

    Bitmap e1 = BitmapFactory.decodeResource(getResources(), R.mipmap.e1);
    Bitmap e2 = BitmapFactory.decodeResource(getResources(), R.mipmap.e2);
    Bitmap e3 = BitmapFactory.decodeResource(getResources(), R.mipmap.e3);
    Bitmap e4 = BitmapFactory.decodeResource(getResources(), R.mipmap.e4);
    Bitmap e5 = BitmapFactory.decodeResource(getResources(), R.mipmap.e5);
    Bitmap e6 = BitmapFactory.decodeResource(getResources(), R.mipmap.e6);
    Bitmap e7 = BitmapFactory.decodeResource(getResources(), R.mipmap.e7);
    Bitmap e8 = BitmapFactory.decodeResource(getResources(), R.mipmap.e8);
    Bitmap e9 = BitmapFactory.decodeResource(getResources(), R.mipmap.e9);
    Bitmap e10 = BitmapFactory.decodeResource(getResources(), R.mipmap.e10);
    Bitmap e11 = BitmapFactory.decodeResource(getResources(), R.mipmap.e11);
    Bitmap e12 = BitmapFactory.decodeResource(getResources(), R.mipmap.e12);
    Bitmap e13 = BitmapFactory.decodeResource(getResources(), R.mipmap.e13);
    Bitmap e14 = BitmapFactory.decodeResource(getResources(), R.mipmap.e14);
    Bitmap e15 = BitmapFactory.decodeResource(getResources(), R.mipmap.e15);
    Bitmap e16 = BitmapFactory.decodeResource(getResources(), R.mipmap.e16);
    Bitmap e17 = BitmapFactory.decodeResource(getResources(), R.mipmap.e17);
    Bitmap e18 = BitmapFactory.decodeResource(getResources(), R.mipmap.e18);
    Bitmap e19 = BitmapFactory.decodeResource(getResources(), R.mipmap.e19);
    Bitmap e20 = BitmapFactory.decodeResource(getResources(), R.mipmap.e20);
    Bitmap e21 = BitmapFactory.decodeResource(getResources(), R.mipmap.e21);
    Bitmap e22 = BitmapFactory.decodeResource(getResources(), R.mipmap.e22);



    Bitmap now = e1;

    public SimpleDrawingView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setFocusable(true);
        setFocusableInTouchMode(true);


    }



    // Setup paint with color and stroke styles


    @Override
    protected void onDraw(Canvas canvas) {
        canvas.scale(1.5f, 1.5f);
        canvas.drawBitmap(now, 0, 0, drawPaint);
    }

    public boolean drawEye(int perclos) {


        switch (perclos) {

            case 0:
                now = e1;
                break;
            case 1:
                now = e2;
                break;
            case 2:
                now = e3;
                break;
            case 3:
                now = e4;
                break;
            case 4:
                now = e5;
                break;
            case 5:
                now = e6;
                break;
            case 6:
                now = e7;
                break;
            case 7:
                now = e8;
                break;
            case 8:
                now = e9;
                break;
            case 9:
                now = e10;
                break;
            case 10:
                now = e10;
                break;
            case 11:
                now = e11;
                break;
            case 12:
                now = e12;
                break;
            case 13:
                now = e13;
                break;
            case 14:
                now = e14;
                break;
            case 15:
                now = e15;
                break;
            case 16:
                now = e16;
                break;
            case 17:
                now = e17;
                break;
            case 18:
                now = e18;
                break;
            case 19:
                now = e19;
                break;
            case 20:
                now = e20;
                break;
            case 21:
                now = e21;
                break;
            case 22:
                now = e22;
                break;

        }

        // Force a view to draw again
        postInvalidate();
        return true;
    }
}