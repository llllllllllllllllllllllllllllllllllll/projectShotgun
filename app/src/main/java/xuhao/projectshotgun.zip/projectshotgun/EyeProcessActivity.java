package xuhao.projectshotgun;


import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.RelativeLayout;

import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.CameraBridgeViewBase.CvCameraViewFrame;
import org.opencv.android.CameraBridgeViewBase.CvCameraViewListener2;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import cn.bmob.v3.Bmob;

public class EyeProcessActivity extends Activity implements CvCameraViewListener2 {

    public static final int JAVA_DETECTOR = 0;
    private static final String TAG = "ProjectShotgun";
    private static final Scalar FACE_RECT_COLOR = new Scalar(0, 255, 0, 255);
    // matrix for zooming
    public Mat mZoomWindow;
    public Mat mZoomWindow2;
    public TimmAlgorithm timm = new TimmAlgorithm();
    public DisplayMetrics metrics;

    boolean timmalgorithm = true;//人眼定位算法选择
    private Button button;
    private Mat mRgba;
    private Mat mGray;
    private File mCascadeFile;
    private CascadeClassifier mJavaDetector;
    private double pLeft;//左眼开合度
    private double pRight;//右眼开合度
    private int pRightcount;//帧数计数器
    public static  String installID;
    private float mRelativeFaceSize = 0.2f;//一帧图像中能检测到的最小的人脸大小
    private int mAbsoluteFaceSize = 0;
    private CustomizableCameraView mOpenCvCameraView;
    private SimpleDrawingView draw;
    private double doughyEye = 0;     //眼睛开合最大值初始化为0
    private double dozyEye = 60000;   //眼睛开合最小值初始化为极大值
    private int doughyEyeCounter = 0; //学习计数器
    private double cuteness = 0;      //眼睛开合分度值
    private BaseLoaderCallback mLoaderCallback = new BaseLoaderCallback(this) {
        @Override
        public void onManagerConnected(int status) {
            switch (status) {
                case LoaderCallbackInterface.SUCCESS: {
                    Log.i(TAG, "OpenCV loaded successfully");


                    try {
                        // load cascade file from application resources加载分类文件
                        InputStream is = getResources().openRawResource(R.raw.lbpcascade_frontalface);
                        File cascadeDir = getDir("cascade", Context.MODE_PRIVATE);
                        mCascadeFile = new File(cascadeDir, "lbpcascade_frontalface.xml");
                        FileOutputStream os = new FileOutputStream(mCascadeFile);

                        byte[] buffer = new byte[4096];
                        int bytesRead;
                        while ((bytesRead = is.read(buffer)) != -1) {
                            os.write(buffer, 0, bytesRead);
                        }
                        is.close();
                        os.close();


                        mJavaDetector = new CascadeClassifier(mCascadeFile.getAbsolutePath());
                        if (mJavaDetector.empty()) {
                            Log.e(TAG, "Failed to load cascade classifier");
                            mJavaDetector = null;
                        } else
                            Log.i(TAG, "Loaded cascade classifier from " + mCascadeFile.getAbsolutePath());


                        cascadeDir.delete();


                    } catch (IOException e) {
                        e.printStackTrace();
                        Log.e(TAG, "Failed to load cascade. Exception thrown: " + e);
                    }
                    mOpenCvCameraView.enableFpsMeter();
                    mOpenCvCameraView.setCameraIndex(1);
                    mOpenCvCameraView.enableView();
                }
                break;
                default: {
                    super.onManagerConnected(status);
                }
                break;
            }
        }
    };

    public EyeProcessActivity() {


        Log.i(TAG, "Instantiated new " + this.getClass());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (!OpenCVLoader.initDebug()) {
            Log.e(this.getClass().getSimpleName(), "  OpenCVLoader.initDebug(), not working.");
        } else {
            Log.d(this.getClass().getSimpleName(), "  OpenCVLoader.initDebug(), working.");
        }
        super.onCreate(savedInstanceState);
        Installation install=new Installation();
        installID=install.id(this);//对每一个安装生成唯一编码
        Bmob.initialize(this, "9f24d7b94cb2a9d147c3b8c52c66f380");//将开合度数值上传至服务器为将来做数据分析
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);


        setContentView(R.layout.activity_eye_process);
        mOpenCvCameraView = (CustomizableCameraView) findViewById(R.id.eyeprocess_activity_surface_view);
        mOpenCvCameraView.setCvCameraViewListener(this);
        mOpenCvCameraView.setKeepScreenOn(true);
        mOpenCvCameraView.setMaxFrameSize(1280, 960);
        draw = (SimpleDrawingView) findViewById(R.id.SimpleDrawingView);
        draw.setBackgroundColor(Color.BLACK);
        pLeft = 0;
        pRight = 0;
        pRightcount = 0;
        doughyEye = 0;
        dozyEye = 60000;
        doughyEyeCounter = 0;
        cuteness = 0;
        button = (Button) findViewById(R.id.button_learn);
        metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);


    }



    void learn(View draw) {         //学习按钮使所有数值初始化
        pLeft = 0;
        pRight = 0;
        pRightcount = 0;
        doughyEye = 0;
        dozyEye = 60000;
        doughyEyeCounter = 0;
        cuteness = 0;
    }
    @Override
    public void onPause() {
        super.onPause();
        if (mOpenCvCameraView != null)
            mOpenCvCameraView.disableView();
    }

    @Override
    public void onResume() {
        super.onResume();


        if (!OpenCVLoader.initDebug()) {
            Log.d(TAG, "Internal OpenCV library not found. Using OpenCV Manager for initialization");
            OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_3_0_0, this, mLoaderCallback);
        } else {
            Log.d(TAG, "OpenCV library found inside package. Using it!");
            mLoaderCallback.onManagerConnected(LoaderCallbackInterface.SUCCESS);
        }
    }

    public void onDestroy() {
        super.onDestroy();
        mOpenCvCameraView.disableView();
    }

    public void onCameraViewStarted(int width, int height) {
        mGray = new Mat();
        mRgba = new Mat();
        // mOpenCvCameraView.setPreviewFPS(10, 10);


    }

    public void onCameraViewStopped() {
        mGray.release();
        mRgba.release();
        mZoomWindow.release();
        mZoomWindow2.release();
    }

    public Mat onCameraFrame(CvCameraViewFrame inputFrame) {

        mRgba = inputFrame.rgba();
        mGray = inputFrame.gray();

        if (mAbsoluteFaceSize == 0) {
            int height = mGray.rows();
            if (Math.round(height * mRelativeFaceSize) > 0) {
                mAbsoluteFaceSize = Math.round(height * mRelativeFaceSize);
            }

        }

        if (mZoomWindow == null || mZoomWindow2 == null)
            CreateAuxiliaryMats();

        MatOfRect faces = new MatOfRect();


        if (mJavaDetector != null)       //检测人脸，将测得结果（包围脸部的矩形）放入数组
            mJavaDetector.detectMultiScale(mGray, faces, 1.1, 2, 2,
                        new Size(mAbsoluteFaceSize, mAbsoluteFaceSize), new Size());


        final Rect[] facesArray = faces.toArray();
        double fSize = 0;                                 //若有检测到多个人脸，
        int fNum = 0;                                     //取距摄像头最近的人脸
        for (int i = 0; i < facesArray.length; i++) {     //做后续工作
            if (facesArray[i].area() > fSize) {
                fSize = facesArray[i].area();
                fNum = i;
            }

        }


        if (facesArray.length > 0) {

            Mat faceROI = mGray.submat(facesArray[fNum]);
            Imgproc.rectangle(mGray, facesArray[fNum].tl(), facesArray[fNum].br(),
                    FACE_RECT_COLOR, 3);

            //人眼定位算法论文：
            //Timm, F. and Barth, E.: Accurate eye centre localisation by means of gradients:
            // Proceedings of the Int. Conference on Computer Theory and Applications (VISAPP), INSTICC, Algarve, Portugal, pp. 125-130, 2011

            if (timmalgorithm) {
                double thresheye = 50;
                double sigma = timm.kSmoothFaceFactor * facesArray[fNum].width;
                Imgproc.GaussianBlur(faceROI, faceROI, new Size(0, 0), sigma);
                //-- Find eye regions and draw them 框定大致眼部区域减少不必要运算
                int eye_region_width = (int) (facesArray[fNum].width * (timm.kEyePercentWidth / 100.0));
                int eye_region_height = (int) (facesArray[fNum].height * (timm.kEyePercentHeight / 100.0));
                int eye_region_top = (int) (facesArray[fNum].height * (timm.kEyePercentTop / 100.0));
                Rect leftEyeRegion = new Rect((int) (facesArray[fNum].width * (timm.kEyePercentSide / 100.0)), eye_region_top, eye_region_width, eye_region_height);

                Rect rightEyeRegion = new Rect((int) (facesArray[fNum].width - eye_region_width - facesArray[fNum].width * (timm.kEyePercentSide / 100.0)),
                        eye_region_top, eye_region_width, eye_region_height);

                Mat C = faceROI.clone().submat(leftEyeRegion);
                Mat D = faceROI.clone().submat(rightEyeRegion);
              /*  File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "MyAppDir");

                if (!mediaStorageDir.exists()) {
                    if (!mediaStorageDir.mkdirs()) {
                        Log.e(TAG, "failed to create directory");
                        return null;
                    }
                }
                 File mediaFile;

                String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
             */


                //降低分辨率进一步减少运算量
                Imgproc.resize(C, C, new Size(timm.kFastEyeWidth, (((float) timm.kFastEyeWidth) / C.size().width) * C.size().height));
                Imgproc.resize(D, D, new Size(timm.kFastEyeWidth, (((float) timm.kFastEyeWidth) / D.size().width) * D.size().height));

                //noise cancellation

                //  Imgproc.erode(C, C, Imgproc.getStructuringElement(Imgproc.MORPH_CROSS, new Size(3, 3)));
                //  Imgproc.dilate(C, C, Imgproc.getStructuringElement(Imgproc.MORPH_CROSS, new Size(3, 3)));
                //  Imgproc.erode(D, D, Imgproc.getStructuringElement(Imgproc.MORPH_CROSS, new Size(3, 3)));
                //  Imgproc.dilate(D, D, Imgproc.getStructuringElement(Imgproc.MORPH_CROSS, new Size(3, 3)));
                double[][] Carray = timm.matToArray(C);
                double[][] Darray = timm.matToArray(D);

                //定位人眼
                Core.MinMaxLocResult leftResult = timm.findEyeCenter(Carray, C.height(), C);
                Point leftPupil = timm.unscalePoint(leftResult.maxLoc, leftEyeRegion);
                Core.MinMaxLocResult rightResult = timm.findEyeCenter(Darray, D.height(), D);
                Point rightPupil = timm.unscalePoint(rightResult.maxLoc, rightEyeRegion);
                //         Imgproc.resize(C, mZoomWindow, mZoomWindow.size());
                //         Imgproc.resize(D, mZoomWindow2, mZoomWindow2.size());
              /*
                int ROIxLeft = (((int) leftPupil.x - C.cols() / 4) > 0) ? ((int) leftPupil.x - C.cols() / 4) : 0;
                int ROIyLeft = (((int) leftPupil.y - C.rows() / 4) > 0) ? ((int) leftPupil.y - C.rows() / 4) : 0;
                int ROIwLeft = ((C.cols() - ROIxLeft) > (C.cols() / 2)) ? (C.cols() / 2) : (C.cols() - ROIxLeft);
                int ROIhLeft = ((C.rows() - ROIyLeft) > (C.rows() / 2)) ? (C.rows() / 2) : (C.rows() - ROIyLeft);
                int ROIxRight = (((int) rightPupil.x - D.cols() / 4) > 0) ? ((int) rightPupil.x - D.cols() / 4) : 0;
                int ROIyRight = (((int) rightPupil.y - D.rows() / 4) > 0) ? ((int) rightPupil.y - D.rows() / 4) : 0;
                int ROIwRight = ((D.cols() - ROIxRight) > (D.cols() / 2)) ? (D.cols() / 2) : (D.cols() - ROIxRight);
                int ROIhRight = ((D.rows() - ROIyRight) > (D.rows() / 2)) ? (D.rows() / 2) : (D.rows() - ROIyRight);

                   if(ROIxLeft>0&&ROIyLeft>0&&(ROIxLeft+ROIwLeft)>C.cols()&&(ROIyLeft+ROIhLeft)>C.rows()&&ROIxRight>0&&ROIyRight>0&&(ROIxRight+ROIwRight)<D.cols()&&(ROIyRight+ROIhRight)<D.rows()) {
                   Rect lr = new Rect(ROIxLeft, ROIyLeft, ROIwLeft, ROIhLeft);
                   Rect rr = new Rect(ROIxRight, ROIyRight, ROIwRight, ROIhRight);

                Mat lm = C.submat(lr);
                Mat rm = D.submat(rr);
              */
                // change eye centers to face coordinates
                rightPupil.x += rightEyeRegion.x;
                rightPupil.y += rightEyeRegion.y;
                leftPupil.x += leftEyeRegion.x;
                leftPupil.y += leftEyeRegion.y;
                // to frame coordinates
                rightPupil.x += facesArray[fNum].tl().x;
                rightPupil.y += facesArray[fNum].tl().y;
                leftPupil.x += facesArray[fNum].tl().x;
                leftPupil.y += facesArray[fNum].tl().y;
                Imgproc.circle(mGray, rightPupil, 15, new Scalar(255), 1);
                Imgproc.circle(mGray, leftPupil, 15, new Scalar(255), 1);
                Imgproc.line(mGray,new Point(rightPupil.x-10,rightPupil.y),new Point(rightPupil.x+10,rightPupil.y),new Scalar(255),1);
                Imgproc.line(mGray,new Point(rightPupil.x,rightPupil.y+10),new Point(rightPupil.x,rightPupil.y-10),new Scalar(255),1);
                Imgproc.line(mGray,new Point(leftPupil.x-10,leftPupil.y),new Point(leftPupil.x+10,leftPupil.y),new Scalar(255),1);
                Imgproc.line(mGray,new Point(leftPupil.x,leftPupil.y+10),new Point(leftPupil.x,leftPupil.y-10),new Scalar(255),1);
           //     Log.d("lefteyecenter", String.valueOf(leftPupil.x) + "***" + String.valueOf(leftPupil.y));


                //Perclos measurement开合度测量
                if (doughyEyeCounter < 50) {                 //学习过程
                    final int l = (int) leftResult.maxVal;
                    final int r = (int) rightResult.maxVal;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            button.setBackgroundColor(Color.argb(255, 70 + (l / 800), 100 + (r / 400), 0));
                            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(1280, 1440);
                            layoutParams.setMargins(metrics.widthPixels - 1280, 0, metrics.widthPixels, metrics.heightPixels);
                            mOpenCvCameraView.setLayoutParams(layoutParams);

                        }
                    });


                    if (doughyEye < (leftResult.maxVal + rightResult.maxVal)) {
                        doughyEye = leftResult.maxVal + rightResult.maxVal;

                    }
                    if (dozyEye > (leftResult.maxVal + rightResult.maxVal)) {
                        dozyEye = leftResult.maxVal + rightResult.maxVal;
                    }
                    cuteness = (doughyEye - dozyEye) / 22;
                    doughyEyeCounter++;
                }
                if (doughyEyeCounter > 49) {         //学习完毕开始监测
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            button.setBackgroundColor(Color.LTGRAY);

                        }
                    });

                    draw.drawEye((int) (((leftResult.maxVal + rightResult.maxVal) - dozyEye) / cuteness));   //动画模拟眼睛当前状态
                  //  mediaFile = new File(mediaStorageDir.getPath() + File.separator + "testimage_" + String.valueOf(leftResult.maxVal + rightResult.maxVal) + ".png");
                   // Imgcodecs.imwrite(mediaFile.toString(), C);

                  //  final String uploadedP=String.valueOf(leftResult.maxVal + rightResult.maxVal);

                    pLeft = pLeft + leftResult.maxVal;
                    pRight = pRight + rightResult.maxVal;
                    //mediaFile = new File(mediaStorageDir.getPath() + File.separator + "testimage_" + timeStamp + String.valueOf(leftResult.maxVal + rightResult.maxVal) + ".png");
                    //Imgcodecs.imwrite(mediaFile.toString(), C);
                    //Imgcodecs.imwrite(mediaFile.toString(), D);
                    pRightcount++;
                    if (pRightcount > 7) {

                        pRightcount = 0;


                        if ((pLeft + pRight) < (dozyEye + cuteness * 2) * 8) {   //阈值判断

              //              Log.d("perclosRatio", String.valueOf(faceROI.cols()) + "***" + String.valueOf(faceROI.rows()));
                            try {
                                Uri notification = Uri.parse("android.resource://xuhao.projectshotgun/raw/ring");

                                Ringtone ring = RingtoneManager.getRingtone(getApplicationContext(), notification);
                                ring.play();
                            } catch (Exception e) {
                                e.printStackTrace();
                    }
                }
                        pRight = 0;
                        pLeft = 0;
                    }
                 /*   BmobFile bmobFile = new BmobFile(mediaFile);

                    bmobFile.upload(this, new UploadFileListener() {
                        @Override
                        public void onSuccess() {
                            Log.d("upload","success");
                        }

                        @Override
                        public void onFailure(int i, String s) {
                           Log.d("upload","fail");
                        }
                    });
                   */
                    /*
                    eye upeye=new eye();
                    upeye.setPerclos(String.valueOf(leftResult.maxVal + rightResult.maxVal));
                    upeye.setTime(timeStamp);
                    upeye.setUUID(installID);
                    upeye.save(this);

                    */

                }
                //}

            } else {


                //simple binarization operation

                // compute the eye area

                Rect eyearea_right = new Rect(facesArray[fNum].x + facesArray[fNum].width / 6,
                        (int) (facesArray[fNum].y + (facesArray[fNum].height / 3.0)),
                        (facesArray[fNum].width - 2 * facesArray[fNum].width / 6) / 2, (int) (facesArray[fNum].height / 6.0));
                Rect eyearea_left = new Rect(facesArray[fNum].x + facesArray[fNum].width / 6
                        + (facesArray[fNum].width - 2 * facesArray[fNum].width / 6) / 2,
                        (int) (facesArray[fNum].y + (facesArray[fNum].height / 3.0)),
                        (facesArray[fNum].width - 2 * facesArray[fNum].width / 6) / 2, (int) (facesArray[fNum].height / 6.0));

                // draw the area


                Imgproc.rectangle(mGray, eyearea_left.tl(), eyearea_left.br(),
                        new Scalar(255, 0, 0, 255), 2);
                Imgproc.rectangle(mGray, eyearea_right.tl(), eyearea_right.br(),
                        new Scalar(255, 0, 0, 255), 2);


                Mat mlefteye = mGray.submat(eyearea_left);
                Mat mrighteye = mGray.submat(eyearea_right);
                Mat mthreshleft = new Mat();
                Mat mthreshright = new Mat();

                //debug
                int a = mlefteye.channels();
                String b = String.valueOf(a);
                Log.d("channels", b);


                //invert the eye area to do Thresh_TO_ZERO
                Mat C = mlefteye.clone();
                Mat D = mrighteye.clone();
                Size sizeA = mlefteye.size();
                for (int e = 0; e < sizeA.height; e++) {
                    for (int j = 0; j < sizeA.width; j++) {
                        double[] data = mlefteye.get(e, j);
                        data[0] = 255.0 - data[0];
                        C.put(e, j, data[0]);
                        data = mrighteye.get(e, j);
                        data[0] = 255.0 - data[0];
                        D.put(e, j, data[0]);
                    }
                }
                Imgproc.threshold(C, mthreshleft, 220, 255, Imgproc.THRESH_TOZERO);
                Imgproc.threshold(D, mthreshright, 220, 255, Imgproc.THRESH_TOZERO);

                //noise cancellation
                Imgproc.erode(mthreshleft, mthreshleft, Imgproc.getStructuringElement(Imgproc.MORPH_ERODE, new Size(2, 2)));
                Imgproc.dilate(mthreshleft, mthreshleft, Imgproc.getStructuringElement(Imgproc.MORPH_DILATE, new Size(2, 2)));
                Imgproc.erode(mthreshright, mthreshright, Imgproc.getStructuringElement(Imgproc.MORPH_ERODE, new Size(2, 2)));
                Imgproc.dilate(mthreshright, mthreshright, Imgproc.getStructuringElement(Imgproc.MORPH_DILATE, new Size(2, 2)));

                //   find upper and bottom line of biggest blob in the area,and calculate height
                double countleft;
                int up = 0;
                int bottom = 0;
           //     Log.d("size", String.valueOf(mthreshleft.size().height));
                for (int e = 0; e < mthreshleft.size().height; e++) {
                    countleft = 0;
                    int s = 0;
                    for (int j = 0; j < mthreshleft.size().width; j++) {

                        double[] data = mthreshleft.get(e, j);
                        if (up == 0) {
                            if (data[0] > 0) {
                                s++;
              //          Log.d("test", String.valueOf(e));
                    }
                            if (s > 5)
                                up = e + 1;
                        } else {
                            countleft = countleft + data[0];
                }

                    }
                    if (countleft == 0 && up != 0) {
                        bottom = e;

                //        Log.d("test", String.valueOf(e));
                        break;
                    }

                }
                countleft = bottom - up;
             //   Log.d("Left Eye Count", String.valueOf(countleft));
            //    Log.d("Left Up", String.valueOf(up));
           //     Log.d("Left buttom", String.valueOf(bottom));
                double countRightEye;
                up = 0;
                bottom = 0;
                for (int e = 0; e < mthreshright.size().height; e++) {
                    countRightEye = 0;
                    int s = 0;
                    for (int j = 0; j < mthreshright.size().width; j++) {

                        double[] data = mthreshright.get(e, j);
                        if (up == 0) {
                            if (data[0] > 0)
                                s++;
                            if (s > 5)
                                up = e + 1;
                        } else {
                            countRightEye = countRightEye + data[0];
                }

                    }
                    if (countRightEye == 0 && up != 0) {
                        bottom = e;
                        break;
                    }

                }
                countRightEye = bottom - up;


                //Perclos measurement
                if ((countRightEye > 0) && (countleft > 0)) {

                    pLeft = pLeft + countleft;
                    pRight = pRight + countRightEye;

                    pRightcount++;
                    if (pRightcount > 5) {

                        pRightcount = 0;

                //        Log.d("perclos", String.valueOf(pLeft + pRight));
                        if ((pLeft + pRight) < 100) {
                       //     Log.d("perclos", String.valueOf(pLeft + pRight));
                            try {
                                // Uri notification = Uri.parse("android.resource://xuhao.projectshotgun/raw/ring");
                                Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                                Ringtone ring = RingtoneManager.getRingtone(getApplicationContext(), notification);
                                ring.play();
                            } catch (Exception e) {
                                e.printStackTrace();
                    }
                }
                        pRight = 0;
                        pLeft = 0;
                    }
                }
             //   Log.d("Right Eye Count", String.valueOf(countRightEye));
                Imgproc.putText(mGray, String.valueOf(countleft), eyearea_left.tl(), Core.FONT_ITALIC, 1.2, new Scalar(255, 255, 255, 255));
                Imgproc.putText(mGray, String.valueOf(countRightEye), eyearea_right.tl(), Core.FONT_ITALIC, 1.2, new Scalar(255, 255, 255, 255));


                // cut eye areas and put them to zoom windows

                //Imgproc.resize(mthreshleft, mZoomWindow2,
                //      mZoomWindow2.size());
                //Imgproc.resize(mthreshright, mZoomWindow,
                //  mZoomWindow.size());

            }


        }
        return mGray;
    }


    private void CreateAuxiliaryMats() {
        if (mGray.empty())
            return;

        int rows = mGray.rows();
        int cols = mGray.cols();

        if (mZoomWindow == null) {
            mZoomWindow = mGray.submat(rows / 2 + rows / 10, rows, cols / 2
                    + cols / 10, cols);
            mZoomWindow2 = mGray.submat(0, rows / 2 - rows / 10, cols / 2
                    + cols / 10, cols);
        }

    }


}